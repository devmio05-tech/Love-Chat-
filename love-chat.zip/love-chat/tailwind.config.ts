import type { Config } from "tailwindcss";

export default {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  darkMode: "media",
  theme: {
    extend: {
      fontFamily: {
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
        serif: ["var(--font-serif)", "Georgia", "serif"],
      },
      colors: {
        wine: { 50: "#FBF1F3", 100: "#F5DDE3", 300: "#DE97A8", 500: "#B04A67", 600: "#93354F", 700: "#7A2A41", 900: "#3D1421" },
        ivory: "#FBF6F3",
        ink: "#1F1A1C",
        night: { 800: "#221A20", 900: "#17121A" },
        gold: "#C39A62",
      },
      boxShadow: { soft: "0 1px 2px rgba(31,26,28,.06), 0 8px 24px rgba(31,26,28,.08)" },
    },
  },
  plugins: [],
} satisfies Config;
