-- =====================================================================
-- Love Chat — schema Supabase (rulează o singură dată în SQL Editor)
-- =====================================================================
create extension if not exists pgcrypto;

-- ---------- Profiluri: exact cei doi membri ----------
create table if not exists public.profiles (
  id           uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (char_length(display_name) between 1 and 40),
  lang         text not null check (lang in ('ro', 'vi')),
  role         text not null check (role in ('boy', 'girl')),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
-- Un singur profil per limbă => maximum 2 profiluri (ro + vi).
create unique index if not exists profiles_one_per_lang on public.profiles(lang);
create unique index if not exists profiles_one_per_role on public.profiles(role);

-- ---------- Mesaje ----------
create table if not exists public.messages (
  id                   uuid primary key default gen_random_uuid(),
  client_id            uuid not null,                       -- idempotență (fără duplicate)
  sender_id            uuid not null references public.profiles(id) on delete cascade,
  original_text        text not null check (char_length(original_text) between 1 and 4000),
  original_lang        text not null check (original_lang in ('ro', 'vi')),
  translated_text      text,
  translated_lang      text not null check (translated_lang in ('ro', 'vi')),
  translation_status   text not null default 'pending' check (translation_status in ('pending', 'done', 'failed')),
  translation_error    text,
  translation_attempts int  not null default 0,
  locked_at            timestamptz,
  translated_at        timestamptz,
  created_at           timestamptz not null default now(),
  constraint messages_lang_differs check (original_lang <> translated_lang),
  constraint messages_sender_client_unique unique (sender_id, client_id),
  constraint messages_done_has_text check (translation_status <> 'done' or translated_text is not null)
);
create index if not exists messages_created_idx on public.messages(created_at, id);

-- ---------- Originalul nu poate fi modificat; traducerea nu poate fi suprascrisă ----------
create or replace function public.messages_protect() returns trigger
language plpgsql as $$
begin
  if new.original_text is distinct from old.original_text
     or new.original_lang is distinct from old.original_lang
     or new.sender_id is distinct from old.sender_id
     or new.client_id is distinct from old.client_id
     or new.created_at is distinct from old.created_at then
    raise exception 'Câmpurile originale ale mesajului sunt imuabile';
  end if;
  if old.translated_text is not null and new.translated_text is distinct from old.translated_text then
    raise exception 'Traducerea a fost deja salvată';
  end if;
  return new;
end $$;
drop trigger if exists messages_protect on public.messages;
create trigger messages_protect before update on public.messages
for each row execute function public.messages_protect();

-- ---------- Cine este membru? ----------
create or replace function public.is_member() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid());
$$;
revoke all on function public.is_member() from public;
grant execute on function public.is_member() to authenticated;

-- ---------- Row Level Security ----------
alter table public.profiles enable row level security;
alter table public.messages enable row level security;

drop policy if exists "members read profiles" on public.profiles;
create policy "members read profiles" on public.profiles
  for select to authenticated using (public.is_member());

drop policy if exists "members read messages" on public.messages;
create policy "members read messages" on public.messages
  for select to authenticated using (public.is_member());

-- Nicio politică de INSERT/UPDATE/DELETE pentru browser: toate scrierile trec prin server
-- (rute API Next.js), care verifică identitatea, validează textul și traduce.
revoke insert, update, delete on public.messages from anon, authenticated;
revoke insert, update, delete on public.profiles from anon, authenticated;
revoke all on public.messages from anon;
revoke all on public.profiles from anon;

-- ---------- Rezervare atomică a traducerii (fără traduceri duble) ----------
create or replace function public.claim_translation(p_id uuid, p_max_attempts int default 5)
returns setof public.messages
language sql security definer set search_path = public as $$
  update public.messages
     set locked_at = now(), translation_status = 'pending'
   where id = p_id
     and translated_text is null
     and translation_status in ('pending', 'failed')
     and translation_attempts < p_max_attempts
     and (locked_at is null or locked_at < now() - interval '30 seconds')
  returning *;
$$;
revoke all on function public.claim_translation(uuid, int) from public, anon, authenticated;
grant execute on function public.claim_translation(uuid, int) to service_role;

-- ---------- Realtime ----------
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'messages'
  ) then
    alter publication supabase_realtime add table public.messages;
  end if;
end $$;
