-- Rulează DUPĂ ce ai creat cele două conturi în Authentication → Users.
-- Înlocuiește cele două UUID-uri cu ID-urile reale ale conturilor.
insert into public.profiles (id, display_name, lang, role) values
  ('UUID-CONT-DEVMIO', 'Devmio', 'ro', 'boy'),
  ('UUID-CONT-EA',     'Iubita mea', 'vi', 'girl');
