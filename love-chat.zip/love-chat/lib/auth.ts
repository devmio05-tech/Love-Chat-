import "server-only";
import { NextResponse } from "next/server";
import { createClient } from "./supabase/server";
import { createAdminClient } from "./supabase/admin";
import type { Profile } from "./types";

export type MemberContext = { userId: string; me: Profile; other: Profile; profiles: Profile[] };
export type MemberResult = { ok: true; ctx: MemberContext } | { ok: false; status: 401 | 403 | 500; error: string };

/**
 * Identifică utilizatorul (cookie de sesiune sau Bearer token) și verifică
 * pe server că este unul dintre cei doi membri ai conversației.
 */
export async function getMember(req?: Request): Promise<MemberResult> {
  let userId: string | null = null;
  try {
    const authz = req?.headers.get("authorization");
    if (authz?.toLowerCase().startsWith("bearer ")) {
      const { data } = await createAdminClient().auth.getUser(authz.slice(7).trim());
      userId = data.user?.id ?? null;
    } else {
      const supabase = await createClient();
      const { data } = await supabase.auth.getUser();
      userId = data.user?.id ?? null;
    }
  } catch {
    userId = null;
  }
  if (!userId) return { ok: false, status: 401, error: "Neautentificat." };

  const { data, error } = await createAdminClient().from("profiles").select("id, display_name, lang, role");
  if (error || !data) return { ok: false, status: 500, error: "Profilurile nu au putut fi citite." };
  const profiles = data as Profile[];
  const me = profiles.find((p) => p.id === userId);
  if (!me) return { ok: false, status: 403, error: "Acest cont nu are acces la conversație." };
  const other = profiles.find((p) => p.id !== userId);
  if (!other || profiles.length !== 2) {
    return { ok: false, status: 500, error: "Configurare incompletă: trebuie exact 2 profiluri." };
  }
  return { ok: true, ctx: { userId, me, other, profiles } };
}

export function jsonError(status: number, error: string) {
  return NextResponse.json({ error }, { status, headers: { "Cache-Control": "no-store" } });
}
