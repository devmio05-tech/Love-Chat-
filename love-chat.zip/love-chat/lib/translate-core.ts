import type { Lang } from "./types";

export const SUPPORTED_LANGS: readonly Lang[] = ["ro", "vi"];

export class TranslationError extends Error {
  readonly retryable: boolean;
  constructor(message: string, retryable = true) {
    super(message);
    this.name = "TranslationError";
    this.retryable = retryable;
  }
}

export interface TranslateOptions {
  apiKey: string | undefined;
  fetchImpl?: typeof fetch;
  timeoutMs?: number;
}

const ENDPOINT = "https://translation.googleapis.com/language/translate/v2";

/**
 * Traduce un text prin Google Cloud Translation API (Basic v2).
 * Nu inventează niciodată o traducere: la orice problemă aruncă TranslationError.
 */
export async function translateText(text: string, source: Lang, target: Lang, opts: TranslateOptions): Promise<string> {
  if (!opts.apiKey) throw new TranslationError("Lipsește GOOGLE_TRANSLATE_API_KEY pe server.", false);
  if (!SUPPORTED_LANGS.includes(source) || !SUPPORTED_LANGS.includes(target)) {
    throw new TranslationError("Limbă nesuportată.", false);
  }
  if (source === target) throw new TranslationError("Limba sursă și cea țintă sunt identice.", false);

  const fetchImpl = opts.fetchImpl ?? fetch;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), opts.timeoutMs ?? 10_000);
  let res: Response;
  try {
    res = await fetchImpl(ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json; charset=utf-8", "X-Goog-Api-Key": opts.apiKey },
      // format "text": păstrează rândurile noi și nu transformă caracterele în entități HTML.
      body: JSON.stringify({ q: text, source, target, format: "text" }),
      signal: controller.signal,
    });
  } catch {
    throw new TranslationError("Serviciul de traducere nu răspunde.", true);
  } finally {
    clearTimeout(timer);
  }

  if (!res.ok) {
    const retryable = res.status === 429 || res.status >= 500;
    throw new TranslationError(`Serviciul de traducere a răspuns cu ${res.status}.`, retryable);
  }

  let json: unknown;
  try {
    json = await res.json();
  } catch {
    throw new TranslationError("Răspuns invalid de la serviciul de traducere.", true);
  }
  const translated = (json as { data?: { translations?: { translatedText?: unknown }[] } })?.data?.translations?.[0]
    ?.translatedText;
  if (typeof translated !== "string" || !translated.trim()) {
    throw new TranslationError("Serviciul de traducere a întors un rezultat gol.", true);
  }
  return translated.normalize("NFC");
}
