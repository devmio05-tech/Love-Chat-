import "server-only";
import type { Lang } from "./types";
import { translateText } from "./translate-core";

export function translate(text: string, source: Lang, target: Lang): Promise<string> {
  return translateText(text, source, target, { apiKey: process.env.GOOGLE_TRANSLATE_API_KEY });
}
