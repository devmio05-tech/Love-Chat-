export type Lang = "ro" | "vi";
export type TranslationStatus = "pending" | "done" | "failed";

export interface Profile {
  id: string;
  display_name: string;
  lang: Lang;
  role: "boy" | "girl";
}

export interface Message {
  id: string;
  client_id: string;
  sender_id: string;
  original_text: string;
  original_lang: Lang;
  translated_text: string | null;
  translated_lang: Lang;
  translation_status: TranslationStatus;
  translation_error: string | null;
  translation_attempts: number;
  created_at: string;
  translated_at: string | null;
}

/** Mesaj din interfață: poate fi încă local (optimist) până confirmă serverul. */
export interface ClientMessage extends Message {
  local?: "sending" | "unsent";
}
