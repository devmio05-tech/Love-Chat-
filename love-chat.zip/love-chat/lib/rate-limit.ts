import "server-only";
import type { SupabaseClient } from "@supabase/supabase-js";

/** Limită simplă, sigură în serverless: numără mesajele expeditorului din ultimul minut. */
export async function underMessageLimit(admin: SupabaseClient, senderId: string): Promise<boolean> {
  const limit = Number(process.env.MESSAGES_PER_MINUTE ?? 20) || 20;
  const since = new Date(Date.now() - 60_000).toISOString();
  const { count, error } = await admin
    .from("messages")
    .select("id", { count: "exact", head: true })
    .eq("sender_id", senderId)
    .gte("created_at", since);
  if (error) return false;
  return (count ?? 0) < limit;
}
