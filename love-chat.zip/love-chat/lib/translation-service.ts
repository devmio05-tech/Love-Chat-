import "server-only";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Message } from "./types";
import { translate } from "./translate";
import { TranslationError } from "./translate-core";

export const MAX_TRANSLATION_ATTEMPTS = 5;

async function readMessage(admin: SupabaseClient, id: string): Promise<Message> {
  const { data, error } = await admin.from("messages").select("*").eq("id", id).single();
  if (error || !data) throw new Error("Mesajul nu a fost găsit.");
  return data as Message;
}

/**
 * Traduce și salvează traducerea unui mesaj.
 * - Rezervă mesajul atomic în baza de date (claim_translation), deci două cereri simultane
 *   nu traduc același mesaj de două ori.
 * - Textul original nu este modificat niciodată (protejat și de un trigger SQL).
 * - La eșec, mesajul rămâne salvat cu starea "failed" și poate fi reîncercat.
 */
export async function translateAndStore(admin: SupabaseClient, id: string): Promise<Message> {
  const { data: claimed, error } = await admin.rpc("claim_translation", {
    p_id: id,
    p_max_attempts: MAX_TRANSLATION_ATTEMPTS,
  });
  if (error) throw new Error("Rezervarea traducerii a eșuat.");
  const row = (Array.isArray(claimed) ? claimed[0] : claimed) as Message | undefined;
  if (!row) return readMessage(admin, id); // deja tradus, în lucru în altă cerere, sau prea multe încercări

  try {
    const translated = await translate(row.original_text, row.original_lang, row.translated_lang);
    const { data, error: upErr } = await admin
      .from("messages")
      .update({
        translated_text: translated,
        translation_status: "done",
        translation_error: null,
        translation_attempts: row.translation_attempts + 1,
        locked_at: null,
        translated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .is("translated_text", null)
      .select("*")
      .maybeSingle();
    if (upErr) throw upErr;
    return (data as Message | null) ?? readMessage(admin, id);
  } catch (e) {
    const reason = e instanceof TranslationError ? e.message : "Eroare internă la traducere.";
    if (!(e instanceof TranslationError)) console.error("translateAndStore", e);
    const { data } = await admin
      .from("messages")
      .update({
        translation_status: "failed",
        translation_error: reason.slice(0, 200),
        translation_attempts: row.translation_attempts + 1,
        locked_at: null,
      })
      .eq("id", id)
      .is("translated_text", null)
      .select("*")
      .maybeSingle();
    return (data as Message | null) ?? readMessage(admin, id);
  }
}
