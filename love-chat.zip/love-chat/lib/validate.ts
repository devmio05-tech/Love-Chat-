export const MAX_MESSAGE_CHARS = 4000;
export const MAX_NAME_CHARS = 40;

export type Validation = { ok: true; text: string } | { ok: false; error: string };

// Caractere de control invizibile (păstrăm \n și \t).
const CONTROL_CHARS = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;

/** Validează și normalizează textul unui mesaj, fără să-i schimbe sensul. */
export function validateMessageText(input: unknown): Validation {
  if (typeof input !== "string") return { ok: false, error: "Mesajul trebuie să fie text." };
  // NFC: combinăm diacriticele (important pentru vietnameză și română).
  const text = input.replace(/\r\n?/g, "\n").replace(CONTROL_CHARS, "").normalize("NFC").trim();
  if (!text) return { ok: false, error: "Mesajul este gol." };
  if ([...text].length > MAX_MESSAGE_CHARS) {
    return { ok: false, error: `Mesajul depășește ${MAX_MESSAGE_CHARS} de caractere.` };
  }
  return { ok: true, text };
}

export function validateDisplayName(input: unknown): Validation {
  if (typeof input !== "string") return { ok: false, error: "Numele trebuie să fie text." };
  const text = input.replace(CONTROL_CHARS, "").replace(/\s+/g, " ").normalize("NFC").trim();
  if (!text) return { ok: false, error: "Numele este gol." };
  if ([...text].length > MAX_NAME_CHARS) return { ok: false, error: `Maxim ${MAX_NAME_CHARS} de caractere.` };
  return { ok: true, text };
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
export function isUuid(value: unknown): value is string {
  return typeof value === "string" && UUID_RE.test(value);
}
