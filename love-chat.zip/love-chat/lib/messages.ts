import type { ClientMessage, Message } from "./types";

/** Timp în ms; Postgres poate întoarce microsecunde, pe care le tăiem la milisecunde. */
export function msgTime(iso: string): number {
  return Date.parse(iso.replace(/(\.\d{3})\d+/, "$1"));
}

export function compareMessages(a: Message, b: Message): number {
  const d = msgTime(a.created_at) - msgTime(b.created_at);
  if (d !== 0) return d;
  return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
}

function pick(prev: ClientMessage, next: ClientMessage): ClientMessage {
  // Un eveniment întârziat nu trebuie să anuleze o traducere deja primită.
  if (!next.local && prev.translation_status === "done" && next.translation_status !== "done") return prev;
  if (next.local) return { ...prev, ...next };
  const { local: _ignored, ...rest } = { ...prev, ...next };
  void _ignored;
  return rest;
}

/**
 * Combină mesajele existente cu cele noi (din server, realtime sau optimiste):
 * - fără duplicate (după id și după client_id al expeditorului),
 * - mesajul optimist este înlocuit de cel confirmat de server,
 * - ordonare după data trimiterii.
 */
export function mergeMessages(current: ClientMessage[], incoming: ClientMessage[]): ClientMessage[] {
  const byId = new Map<string, ClientMessage>();
  for (const m of current) byId.set(m.id, m);

  for (const m of incoming) {
    if (!m || !m.id) continue;
    const sameClient = (x: ClientMessage) => x.client_id === m.client_id && x.sender_id === m.sender_id && x.id !== m.id;
    if (m.local) {
      // Dacă serverul a confirmat deja acest mesaj, ignorăm varianta locală.
      if ([...byId.values()].some((x) => !x.local && sameClient(x))) continue;
    } else {
      for (const [id, x] of byId) if (x.local && sameClient(x)) byId.delete(id);
    }
    const prev = byId.get(m.id);
    byId.set(m.id, prev ? pick(prev, m) : m);
  }
  return [...byId.values()].sort(compareMessages);
}

/** Mesajul afișat utilizatorului care citește (viewerId). */
export function visibleText(m: Message, viewerId: string, showAlternate: boolean): string | null {
  const mine = m.sender_id === viewerId;
  if (mine) return showAlternate ? m.translated_text : m.original_text;
  // Destinatarul vede traducerea; originalul doar dacă cere explicit „Vezi originalul”.
  return showAlternate ? m.original_text : m.translation_status === "done" ? m.translated_text : null;
}
