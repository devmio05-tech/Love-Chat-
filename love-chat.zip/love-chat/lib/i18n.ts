import type { Lang } from "./types";

const dict = {
  typeMessage: { ro: "Scrie un mesaj…", vi: "Nhập tin nhắn…" },
  send: { ro: "Trimite", vi: "Gửi" },
  showOriginal: { ro: "Vezi originalul", vi: "Xem bản gốc" },
  backToTranslation: { ro: "Înapoi la traducere", vi: "Quay lại bản dịch" },
  showTranslation: { ro: "Vezi traducerea", vi: "Xem bản dịch" },
  backToMine: { ro: "Înapoi la mesajul meu", vi: "Quay lại tin nhắn của tôi" },
  original: { ro: "Original", vi: "Bản gốc" },
  translating: { ro: "Se traduce…", vi: "Đang dịch…" },
  translated: { ro: "Tradus", vi: "Đã dịch" },
  translationFailed: { ro: "Traducerea nu a reușit", vi: "Dịch không thành công" },
  retry: { ro: "Reîncearcă", vi: "Thử lại" },
  sending: { ro: "Se trimite…", vi: "Đang gửi…" },
  unsent: { ro: "Netrimis", vi: "Chưa gửi được" },
  resend: { ro: "Retrimite", vi: "Gửi lại" },
  online: { ro: "Conectat", vi: "Đã kết nối" },
  connecting: { ro: "Se conectează…", vi: "Đang kết nối…" },
  offline: {
    ro: "Fără internet. Mesajele se sincronizează când revine conexiunea.",
    vi: "Mất kết nối mạng. Tin nhắn sẽ được đồng bộ khi có mạng lại.",
  },
  today: { ro: "Azi", vi: "Hôm nay" },
  yesterday: { ro: "Ieri", vi: "Hôm qua" },
  settings: { ro: "Setări", vi: "Cài đặt" },
  logout: { ro: "Ieșire", vi: "Đăng xuất" },
  autoTranslate: { ro: "Traducere automată", vi: "Tự động dịch" },
  emptyTitle: { ro: "Începeți conversația", vi: "Hãy bắt đầu trò chuyện" },
  displayName: { ro: "Nume afișat", vi: "Tên hiển thị" },
  language: { ro: "Limba", vi: "Ngôn ngữ" },
  save: { ro: "Salvează", vi: "Lưu" },
  saved: { ro: "Salvat ✓", vi: "Đã lưu ✓" },
  back: { ro: "Înapoi", vi: "Quay lại" },
  langRo: { ro: "Română", vi: "Tiếng Romania" },
  langVi: { ro: "Vietnameză", vi: "Tiếng Việt" },
  errorSend: { ro: "Mesajul nu a putut fi trimis.", vi: "Không gửi được tin nhắn." },
  errorSave: { ro: "Nu s-a putut salva.", vi: "Không lưu được." },
  you: { ro: "Tu", vi: "Bạn" },
} as const;

export type I18nKey = keyof typeof dict;

export function t(lang: Lang, key: I18nKey): string {
  return dict[key][lang];
}

export function emptyText(lang: Lang, otherName: string): string {
  return lang === "ro"
    ? `Tu scrii în română, ${otherName} citește în vietnameză. Și invers.`
    : `Bạn viết bằng tiếng Việt, ${otherName} đọc bằng tiếng Romania. Và ngược lại.`;
}

export function theySee(lang: Lang, otherName: string): string {
  return lang === "ro" ? `Așa vede ${otherName}:` : `${otherName} sẽ thấy:`;
}

export function langName(viewer: Lang, l: Lang): string {
  return t(viewer, l === "ro" ? "langRo" : "langVi");
}
