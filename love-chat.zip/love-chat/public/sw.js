// Service worker minimal pentru instalarea ca aplicație (PWA).
// Intenționat NU salvează mesajele în cache: conversația rămâne doar în baza de date.
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (event) => event.waitUntil(self.clients.claim()));
self.addEventListener("fetch", () => {});
