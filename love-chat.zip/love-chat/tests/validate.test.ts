import { test } from "node:test";
import assert from "node:assert/strict";
import { isUuid, validateDisplayName, validateMessageText, MAX_MESSAGE_CHARS } from "../lib/validate";

test("păstrează diacriticele românești, vietnameza și emoji", () => {
  const ro = validateMessageText("  Bună dimineața, iubirea mea! Ăâîșț ȘȚ ❤️😘  ");
  assert.deepEqual(ro, { ok: true, text: "Bună dimineața, iubirea mea! Ăâîșț ȘȚ ❤️😘" });
  const vi = validateMessageText("Em nhớ anh nhiều lắm. Chào buổi sáng 🌸");
  assert.deepEqual(vi, { ok: true, text: "Em nhớ anh nhiều lắm. Chào buổi sáng 🌸" });
});

test("normalizează diacriticele descompuse (NFD → NFC)", () => {
  const nfd = "nhớ".normalize("NFD");
  const r = validateMessageText(nfd);
  assert.ok(r.ok);
  if (r.ok) assert.equal(r.text, "nhớ".normalize("NFC"));
});

test("păstrează paragrafele și scoate caracterele de control", () => {
  const r = validateMessageText("Rând 1\r\nRând 2\n\nParagraf\u0007");
  assert.deepEqual(r, { ok: true, text: "Rând 1\nRând 2\n\nParagraf" });
});

test("respinge mesaje goale, non-text și prea lungi", () => {
  assert.equal(validateMessageText("   ").ok, false);
  assert.equal(validateMessageText(42).ok, false);
  assert.equal(validateMessageText(undefined).ok, false);
  assert.equal(validateMessageText("a".repeat(MAX_MESSAGE_CHARS + 1)).ok, false);
  assert.equal(validateMessageText("😀".repeat(MAX_MESSAGE_CHARS)).ok, true); // emoji numărat ca un caracter
});

test("validează numele afișat și UUID-urile", () => {
  assert.deepEqual(validateDisplayName("  Iubita   mea "), { ok: true, text: "Iubita mea" });
  assert.equal(validateDisplayName("").ok, false);
  assert.equal(validateDisplayName("x".repeat(41)).ok, false);
  assert.equal(isUuid("2f1b6a4e-6d1c-4a8e-9b7d-3c2a1e0f9d8c"), true);
  assert.equal(isUuid("nu-e-uuid"), false);
  assert.equal(isUuid(null), false);
});
