import { test } from "node:test";
import assert from "node:assert/strict";
import { mergeMessages, visibleText, compareMessages } from "../lib/messages";
import type { ClientMessage } from "../lib/types";

const DEV = "11111111-1111-4111-8111-111111111111";
const GIRL = "22222222-2222-4222-8222-222222222222";
let n = 0;
function msg(p: Partial<ClientMessage>): ClientMessage {
  n++;
  return {
    id: `00000000-0000-4000-8000-${String(n).padStart(12, "0")}`,
    client_id: `c${n}`,
    sender_id: DEV,
    original_text: "Bună",
    original_lang: "ro",
    translated_text: null,
    translated_lang: "vi",
    translation_status: "pending",
    translation_error: null,
    translation_attempts: 0,
    created_at: "2026-10-18T10:00:00.000000+00:00",
    translated_at: null,
    ...p,
  };
}

test("fără duplicate când același mesaj vine din API și din realtime", () => {
  const m = msg({});
  const a = mergeMessages([], [m]);
  const b = mergeMessages(a, [{ ...m }]);
  const c = mergeMessages(b, [{ ...m, translation_status: "done", translated_text: "Chào" }]);
  assert.equal(c.length, 1);
  assert.equal(c[0].translated_text, "Chào");
});

test("mesajul optimist este înlocuit de cel confirmat de server", () => {
  const local = msg({ id: "local-x", client_id: "cid-1", local: "sending" });
  const server = msg({ client_id: "cid-1" });
  const out = mergeMessages(mergeMessages([], [local]), [server]);
  assert.equal(out.length, 1);
  assert.equal(out[0].id, server.id);
  assert.equal(out[0].local, undefined);
});

test("un mesaj optimist întârziat nu dublează mesajul deja confirmat", () => {
  const server = msg({ client_id: "cid-2" });
  const out = mergeMessages([server], [msg({ id: "local-y", client_id: "cid-2", local: "sending" })]);
  assert.equal(out.length, 1);
  assert.equal(out[0].id, server.id);
});

test("un eveniment vechi nu anulează o traducere primită", () => {
  const m = msg({ translation_status: "done", translated_text: "Chào" });
  const out = mergeMessages([m], [{ ...m, translation_status: "pending", translated_text: null }]);
  assert.equal(out[0].translation_status, "done");
  assert.equal(out[0].translated_text, "Chào");
});

test("ordonare după data trimiterii (inclusiv microsecunde și formate diferite)", () => {
  const late = msg({ created_at: "2026-10-18T10:00:02.000Z" });
  const early = msg({ created_at: "2026-10-18T10:00:01.123456+00:00" });
  const mid = msg({ created_at: "2026-10-18T10:00:01.500000+00:00" });
  const out = mergeMessages([], [late, early, mid]);
  assert.deepEqual(out.map((x) => x.id), [early.id, mid.id, late.id]);
  assert.ok(compareMessages(early, late) < 0);
});

test("destinatarul vede traducerea, nu originalul; originalul doar la cerere", () => {
  const pending = msg({ sender_id: DEV, original_text: "Te iubesc" });
  assert.equal(visibleText(pending, GIRL, false), null); // traducere în curs: nu se afișează originalul
  assert.equal(visibleText(pending, GIRL, true), "Te iubesc"); // „Vezi originalul”
  const failed = { ...pending, translation_status: "failed" as const };
  assert.equal(visibleText(failed, GIRL, false), null);
  const done = { ...pending, translation_status: "done" as const, translated_text: "Anh yêu em" };
  assert.equal(visibleText(done, GIRL, false), "Anh yêu em");
  assert.equal(visibleText(done, GIRL, true), "Te iubesc"); // a doua apăsare revine
  assert.equal(visibleText(done, DEV, false), "Te iubesc"); // expeditorul își vede textul
  assert.equal(visibleText(done, DEV, true), "Anh yêu em");
});
