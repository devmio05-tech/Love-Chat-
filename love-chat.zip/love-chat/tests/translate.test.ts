import { test } from "node:test";
import assert from "node:assert/strict";
import { translateText, TranslationError } from "../lib/translate-core";

// Teste ale clientului de traducere cu un fetch simulat DOAR în test.
// Ele verifică protocolul și tratarea erorilor; nu înlocuiesc testul cu serviciul real.
function fakeFetch(handler: (url: string, init: RequestInit) => Response | Promise<Response>) {
  const calls: { url: string; init: RequestInit }[] = [];
  const f = (async (url: string | URL | Request, init?: RequestInit) => {
    calls.push({ url: String(url), init: init ?? {} });
    return handler(String(url), init ?? {});
  }) as typeof fetch;
  return { f, calls };
}
const ok = (txt: string) => new Response(JSON.stringify({ data: { translations: [{ translatedText: txt }] } }), { status: 200 });

test("trimite cererea corectă: ro → vi, format text, cheia în header (nu în URL)", async () => {
  const { f, calls } = fakeFetch(() => ok("Chào buổi sáng, tình yêu của anh."));
  const out = await translateText("Bună dimineața, iubirea mea.", "ro", "vi", { apiKey: "TEST_KEY", fetchImpl: f });
  assert.equal(out, "Chào buổi sáng, tình yêu của anh.");
  assert.equal(calls.length, 1);
  assert.ok(!calls[0].url.includes("TEST_KEY"));
  const headers = calls[0].init.headers as Record<string, string>;
  assert.equal(headers["X-Goog-Api-Key"], "TEST_KEY");
  assert.deepEqual(JSON.parse(String(calls[0].init.body)), { q: "Bună dimineața, iubirea mea.", source: "ro", target: "vi", format: "text" });
});

test("direcția vi → ro", async () => {
  const { f, calls } = fakeFetch(() => ok("Mi-e foarte dor de tine."));
  const out = await translateText("Em nhớ anh nhiều lắm.", "vi", "ro", { apiKey: "K", fetchImpl: f });
  assert.equal(out, "Mi-e foarte dor de tine.");
  const body = JSON.parse(String(calls[0].init.body));
  assert.equal(body.source, "vi");
  assert.equal(body.target, "ro");
});

test("fără cheie: eroare clară, fără apel și fără traducere inventată", async () => {
  const { f, calls } = fakeFetch(() => ok("x"));
  await assert.rejects(translateText("Salut", "ro", "vi", { apiKey: undefined, fetchImpl: f }), (e: unknown) => {
    assert.ok(e instanceof TranslationError);
    assert.equal((e as TranslationError).retryable, false);
    return true;
  });
  assert.equal(calls.length, 0);
});

test("eroare 500/429 => reîncercabilă; 400/403 => nereîncercabilă", async () => {
  for (const [status, retryable] of [[500, true], [503, true], [429, true], [400, false], [403, false]] as const) {
    const { f } = fakeFetch(() => new Response("err", { status }));
    await assert.rejects(translateText("Salut", "ro", "vi", { apiKey: "K", fetchImpl: f }), (e: unknown) => {
      assert.ok(e instanceof TranslationError);
      assert.equal((e as TranslationError).retryable, retryable);
      return true;
    });
  }
});

test("răspuns gol sau invalid => eroare, nu text fals", async () => {
  for (const body of ['{"data":{"translations":[{"translatedText":""}]}}', "{}", "nu e json"]) {
    const { f } = fakeFetch(() => new Response(body, { status: 200 }));
    await assert.rejects(translateText("Salut", "ro", "vi", { apiKey: "K", fetchImpl: f }), TranslationError);
  }
});

test("rețea căzută => eroare reîncercabilă", async () => {
  const { f } = fakeFetch(() => {
    throw new TypeError("fetch failed");
  });
  await assert.rejects(translateText("Salut", "ro", "vi", { apiKey: "K", fetchImpl: f }), (e: unknown) => (e as TranslationError).retryable === true);
});

test("respinge aceeași limbă și limbi nesuportate", async () => {
  const { f } = fakeFetch(() => ok("x"));
  await assert.rejects(translateText("Salut", "ro", "ro", { apiKey: "K", fetchImpl: f }), TranslationError);
  // @ts-expect-error limbă nesuportată intenționat
  await assert.rejects(translateText("Hi", "en", "vi", { apiKey: "K", fetchImpl: f }), TranslationError);
});

test("păstrează rândurile noi și emoji din răspuns", async () => {
  const { f } = fakeFetch(() => ok("Dòng 1\nDòng 2 ❤️"));
  assert.equal(await translateText("Rând 1\nRând 2 ❤️", "ro", "vi", { apiKey: "K", fetchImpl: f }), "Dòng 1\nDòng 2 ❤️");
});
