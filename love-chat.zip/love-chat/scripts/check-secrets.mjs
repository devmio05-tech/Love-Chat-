#!/usr/bin/env node
// Verifică faptul că nicio cheie secretă nu ajunge în repository sau în codul trimis browserului.
import { readdirSync, readFileSync, statSync, existsSync } from "node:fs";
import { join, relative } from "node:path";

const root = process.cwd();
const SKIP = new Set(["node_modules", ".git", ".vercel"]);
const problems = [];

function walk(dir, out = []) {
  for (const name of readdirSync(dir)) {
    if (SKIP.has(name)) continue;
    const p = join(dir, name);
    const st = statSync(p);
    if (st.isDirectory()) walk(p, out);
    else if (st.size < 5_000_000) out.push(p);
  }
  return out;
}

const PATTERNS = [
  [/AIza[0-9A-Za-z_\-]{35}/, "cheie Google API"],
  [/sb_secret_[0-9A-Za-z_\-]{10,}/, "cheie secretă Supabase"],
  [/eyJ[A-Za-z0-9_-]{15,}\.eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}/, "JWT (posibil service_role)"],
];

// 1) Fișierele sursă (fără .next) nu conțin chei.
const files = walk(root).filter((f) => !relative(root, f).startsWith(".next") && !/\.env(\.|$)/.test(f.split(/[\\/]/).pop()));
for (const f of files) {
  if (!/\.(ts|tsx|js|mjs|json|md|sql|css|html|example)$/.test(f)) continue;
  const txt = readFileSync(f, "utf8");
  for (const [re, what] of PATTERNS) if (re.test(txt)) problems.push(`${relative(root, f)}: conține ${what}`);
  if (/NEXT_PUBLIC_[A-Z_]*(SERVICE|SECRET|TRANSLATE)/.test(txt)) problems.push(`${relative(root, f)}: secret cu prefix NEXT_PUBLIC_`);
}

// 2) Codul de client nu importă module doar-server.
for (const f of files.filter((f) => /\.(ts|tsx)$/.test(f))) {
  const txt = readFileSync(f, "utf8");
  if (txt.startsWith('"use client"') && /from\s+["']@\/lib\/(supabase\/admin|supabase\/server|translate|translation-service|auth|rate-limit)["']/.test(txt)) {
    problems.push(`${relative(root, f)}: componentă client importă cod doar-server`);
  }
}

// 3) .env este ignorat de git.
const gi = existsSync(join(root, ".gitignore")) ? readFileSync(join(root, ".gitignore"), "utf8") : "";
if (!/^\.env$/m.test(gi) || !/^\.env\.\*$/m.test(gi)) problems.push(".gitignore nu exclude .env / .env.*");

// 4) După `npm run build`: bundle-ul de browser nu conține valorile secrete.
const staticDir = join(root, ".next", "static");
let scanned = 0;
if (existsSync(staticDir)) {
  const secrets = [process.env.SUPABASE_SERVICE_ROLE_KEY, process.env.GOOGLE_TRANSLATE_API_KEY].filter((v) => v && v.length > 8);
  for (const f of walk(staticDir)) {
    const txt = readFileSync(f, "utf8");
    scanned++;
    for (const s of secrets) if (txt.includes(s)) problems.push(`${relative(root, f)}: conține o valoare secretă!`);
    for (const name of ["SUPABASE_SERVICE_ROLE_KEY", "GOOGLE_TRANSLATE_API_KEY"]) if (txt.includes(name)) problems.push(`${relative(root, f)}: menționează ${name}`);
    for (const [re, what] of PATTERNS) if (re.test(txt)) problems.push(`${relative(root, f)}: conține ${what}`);
  }
}

console.log(`Fișiere sursă verificate: ${files.length}. Fișiere din bundle-ul browserului verificate: ${scanned}${scanned ? "" : " (rulează după npm run build)"}.`);
if (problems.length) {
  console.error("PROBLEME:\n - " + problems.join("\n - "));
  process.exit(1);
}
console.log("OK: nicio cheie secretă găsită.");
