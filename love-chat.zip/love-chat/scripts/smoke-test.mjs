#!/usr/bin/env node
/**
 * Test end-to-end pe aplicația REALĂ (după configurarea Supabase + Google + Vercel).
 * Folosește serviciile reale: nu simulează nimic.
 *
 *   BASE_URL=https://love-chat-xxx.vercel.app \
 *   NEXT_PUBLIC_SUPABASE_URL=... NEXT_PUBLIC_SUPABASE_ANON_KEY=... \
 *   DEVMIO_EMAIL=... DEVMIO_PASSWORD=... GIRL_EMAIL=... GIRL_PASSWORD=... \
 *   npm run smoke
 *
 * Atenție: trimite 2 mesaje reale de test în conversație (marcate cu „[test]”).
 */
import { createClient } from "@supabase/supabase-js";
import { randomUUID } from "node:crypto";

const env = (k) => {
  const v = process.env[k];
  if (!v) {
    console.error(`Lipsește variabila ${k}`);
    process.exit(2);
  }
  return v;
};
const BASE = env("BASE_URL").replace(/\/$/, "");
const URL_ = env("NEXT_PUBLIC_SUPABASE_URL");
const ANON = env("NEXT_PUBLIC_SUPABASE_ANON_KEY");
const results = [];
const check = (name, cond, detail = "") => {
  results.push({ name, ok: !!cond, detail });
  console.log(`${cond ? "✅" : "❌"} ${name}${detail ? " — " + detail : ""}`);
};
const client = () => createClient(URL_, ANON, { auth: { persistSession: false } });

async function login(email, password) {
  const c = client();
  const { data, error } = await c.auth.signInWithPassword({ email, password });
  if (error) throw new Error(`Login eșuat pentru ${email}: ${error.message}`);
  return { c, token: data.session.access_token, userId: data.user.id };
}

async function send(token, text, clientId = randomUUID()) {
  const res = await fetch(`${BASE}/api/messages`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify({ clientId, text }),
  });
  return { status: res.status, json: await res.json().catch(() => null), clientId };
}

function waitForTranslation(c, messageId, ms = 20000) {
  return new Promise((resolve) => {
    const timer = setTimeout(() => { c.removeChannel(ch); resolve(null); }, ms);
    const ch = c
      .channel("smoke-" + messageId)
      .on("postgres_changes", { event: "*", schema: "public", table: "messages" }, (p) => {
        if (p.new?.id === messageId && p.new.translation_status === "done") {
          clearTimeout(timer); c.removeChannel(ch); resolve(p.new);
        }
      })
      .subscribe();
  });
}

const RO = "[test] Bună dimineața, iubirea mea. Ai dormit bine? ăâîșț ❤️";
const VI = "[test] Em nhớ anh nhiều lắm. 🌸";

try {
  // Testul 8: neautentificat
  const anon = client();
  const anonRead = await anon.from("messages").select("id").limit(1);
  check("8. Neautentificat nu poate citi mesaje", !anonRead.data?.length, anonRead.error?.message ?? `${anonRead.data?.length ?? 0} rânduri`);
  const anonSend = await fetch(`${BASE}/api/messages`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ clientId: randomUUID(), text: "hack" }) });
  check("8. Neautentificat nu poate trimite", anonSend.status === 401, `status ${anonSend.status}`);
  const anonInsert = await anon.from("messages").insert({ client_id: randomUUID(), sender_id: randomUUID(), original_text: "x", original_lang: "ro", translated_lang: "vi" });
  check("8. Inserare directă în DB blocată", !!anonInsert.error, anonInsert.error?.message ?? "inserat!");

  const dev = await login(env("DEVMIO_EMAIL"), env("DEVMIO_PASSWORD"));
  const girl = await login(env("GIRL_EMAIL"), env("GIRL_PASSWORD"));
  girl.c.realtime.setAuth(girl.token);
  dev.c.realtime.setAuth(dev.token);

  // Testul 1 + 5: RO → VI, primit în timp real de ea
  const r1 = await send(dev.token, RO);
  const m1 = r1.json?.message;
  check("1. Mesaj RO salvat", r1.status === 201 && m1?.original_text === RO.normalize("NFC"), `status ${r1.status}`);
  const live1 = m1?.translation_status === "done" ? m1 : await waitForTranslation(girl.c, m1?.id);
  check("1. Ea primește traducerea în vietnameză", live1?.translation_status === "done" && live1?.translated_lang === "vi" && !!live1?.translated_text && live1.translated_text !== RO, live1?.translated_text ?? "fără traducere");
  const girlView = await girl.c.from("messages").select("*").eq("id", m1?.id).single();
  check("5. Ea vede mesajul din baza de date (RLS ok)", girlView.data?.translated_lang === "vi", girlView.error?.message ?? "");

  // Testul 2: VI → RO
  const r2 = await send(girl.token, VI);
  const m2 = r2.json?.message;
  const live2 = m2?.translation_status === "done" ? m2 : await waitForTranslation(dev.c, m2?.id);
  check("2. Devmio primește traducerea în română", live2?.translated_lang === "ro" && !!live2?.translated_text, live2?.translated_text ?? "fără traducere");

  // Testul 3 + 6: originalul păstrat exact, cu diacritice și emoji
  check("3/6. Originalul RO păstrat exact (diacritice + emoji)", girlView.data?.original_text === RO.normalize("NFC"));
  check("3/6. Originalul VI păstrat exact", live2?.original_text === VI.normalize("NFC"));

  // Testul 7: idempotență — retrimiterea aceleiași cereri nu dublează mesajul
  const again = await send(dev.token, RO, r1.clientId);
  check("7. Retrimiterea nu creează duplicat", again.json?.message?.id === m1?.id, `${again.json?.message?.id} vs ${m1?.id}`);

  // Testul 4: persistență — client nou, istoric încărcat
  const fresh = await login(env("DEVMIO_EMAIL"), env("DEVMIO_PASSWORD"));
  const hist = await fresh.c.from("messages").select("id").in("id", [m1?.id, m2?.id].filter(Boolean));
  check("4. Mesajele rămân salvate (sesiune nouă)", hist.data?.length === 2);
} catch (e) {
  check("Execuție", false, e instanceof Error ? e.message : String(e));
}

const failed = results.filter((r) => !r.ok).length;
console.log(`\n${results.length - failed}/${results.length} verificări trecute.`);
process.exit(failed ? 1 : 0);
