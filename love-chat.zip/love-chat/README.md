# Love Chat ♥ RO ⇄ VI

Aplicație privată de mesagerie între **Devmio** (română) și **iubita lui** (vietnameză), cu traducere automată în ambele direcții, mesaje salvate și sincronizare în timp real.

**Stack:** Next.js 15 (App Router) + TypeScript + Tailwind CSS · Supabase (Auth, PostgreSQL, Row Level Security, Realtime) · Google Cloud Translation API · Vercel.

---

## 1. Funcționalități implementate

**Conturi și acces**
- Exact doi utilizatori, fiecare cu cont propriu (email + parolă, Supabase Auth).
- Profil cu nume afișat, limbă (`ro` / `vi`) și rol. Baza de date permite cel mult un profil per limbă, deci maximum doi membri.
- Pagina de **Setări**: schimbi numele afișat, inclusiv „Iubita mea”, fără să modifici codul. Limba nu se poate schimba din interfață.
- Un link public nu e suficient: fără autentificare ești redirecționat la login, iar baza de date refuză citirea (RLS).

**Traducere automată**
- Serverul ia limba sursă din profilul expeditorului și limba țintă din profilul destinatarului: Devmio scrie `ro → vi`, ea scrie `vi → ro`.
- Serviciu real: Google Cloud Translation API, apelat **doar de pe server**.
- Originalul se salvează **înainte** de traducere. Dacă traducerea eșuează, mesajul rămâne salvat cu starea „eșuat”, se reîncearcă automat (cu pauze tot mai mari, maximum 5 încercări) și poate fi reîncercat manual.
- **Nicio traducere dublă:**
  - o funcție SQL rezervă atomic mesajul înainte de traducere;
  - un trigger interzice suprascrierea unei traduceri existente;
  - aceeași cerere retrimisă (același `clientId`) nu creează un mesaj nou.
- Destinatarul **nu vede niciodată originalul în locul traducerii**. Cât timp se traduce, apare o animație discretă; la eșec apare „Traducerea nu a reușit · Reîncearcă”.
- Text normalizat NFC: diacriticele românești (ă â î ș ț) și cele vietnameze rămân corecte. Emoji, rândurile noi și paragrafele sunt păstrate (`format: "text"`).

**Mesajul original**
- Pentru fiecare mesaj se salvează: id, expeditor, text original, limbă originală, text tradus, limba traducerii, data, starea traducerii, eroarea, numărul de încercări și data traducerii.
- **„Vezi originalul”** pe mesajele primite; a doua apăsare duce la **„Înapoi la traducere”**.
- **„Vezi traducerea”** pe mesajele proprii arată exact ce vede celălalt.
- Originalul nu poate fi modificat în baza de date (trigger SQL).

**Timp real și sincronizare**
- Supabase Realtime: mesajele noi și traducerile apar fără reîncărcarea paginii.
- Fără duplicate: mesajele se combină după `id` și `clientId`, iar mesajul optimist e înlocuit de cel confirmat.
- Indicator de stare: Conectat / Se conectează / Fără internet.
- După reconectare sau la revenirea în aplicație, mesajele lipsă sunt recuperate automat.
- Mesaj netrimis din cauza rețelei: „Netrimis · Retrimite”, cu același `clientId`, deci fără duplicat.

**Design**
- Romantic și elegant (bordo și auriu), cu mod întunecat automat.
- Bulele proprii în dreapta, cele primite în stânga, cu avatar cu inițială, nume, oră și separatoare pe zile.
- Elementul „RO ⇄ VI ♥” sugerează limbile diferite.
- Interfața e în limba fiecăruia: română pentru Devmio, vietnameză pentru ea.
- Fonturi cu suport complet pentru vietnameză și română: Be Vietnam Pro și Playfair Display.
- Adaptat pentru iPhone (safe area), Android, tabletă și desktop. Pe calculator, Enter trimite; pe telefon, Enter face rând nou.

**Securitate**
- Autentificare reală, iar autorizarea se face pe server la fiecare rută API (`getMember`).
- RLS: doar cei doi membri pot citi profilurile și mesajele. Browserul nu poate scrie direct în tabele: toate scrierile trec prin server.
- Expeditorul e luat din sesiune, nu din cerere, deci nimeni nu poate trimite „în numele” celuilalt.
- Validare pe server: text, lungime (maximum 4000 de caractere), UUID-uri.
- Limită: 20 de mesaje pe minut per utilizator (configurabilă) și maximum 5 încercări de traducere per mesaj.
- Cheile secrete există doar pe server, prin modulul `server-only`. Scriptul `npm run check:secrets` verifică sursa și bundle-ul.
- Antete HTTP de securitate (HSTS, X-Frame-Options etc.) și `robots: noindex`.

**PWA**
- `manifest.webmanifest`, iconițe (inclusiv maskable și Apple) și un service worker minimal.
- Service worker-ul **nu** salvează mesaje în cache.
- Pe iPhone: Safari → Partajare → „Adaugă pe ecranul principal”.

---

## 2. Structura bazei de date (`supabase/schema.sql`)

**`profiles`**

| coloană | tip | note |
|---|---|---|
| id | uuid PK | = `auth.users.id` |
| display_name | text | 1–40 caractere |
| lang | text | `ro` / `vi`, **unic** |
| role | text | `boy` / `girl`, **unic** |
| created_at, updated_at | timestamptz | |

**`messages`**

| coloană | tip | note |
|---|---|---|
| id | uuid PK | generat |
| client_id | uuid | unic împreună cu `sender_id` (idempotență) |
| sender_id | uuid FK → profiles | |
| original_text | text | 1–4000, **imuabil** |
| original_lang | text | `ro` / `vi` |
| translated_text | text, nullable | nu poate fi suprascris după salvare |
| translated_lang | text | limba destinatarului |
| translation_status | text | `pending` / `done` / `failed` |
| translation_error | text | motivul eșecului |
| translation_attempts | int | maximum 5 |
| locked_at | timestamptz | rezervare traducere |
| translated_at, created_at | timestamptz | |

**Funcții și reguli:**
- `is_member()`: verifică dacă utilizatorul are profil.
- `claim_translation()`: rezervarea atomică a traducerii, apelabilă doar cu cheia secretă.
- Trigger-ul `messages_protect`: protejează originalul și traducerea deja salvată.
- Politici RLS: doar citire pentru membri; nicio scriere directă din browser.
- Tabela `messages` e adăugată în publicația `supabase_realtime`.

---

## 3. Serviciul de traducere

**Google Cloud Translation API – Basic (v2)**, endpoint `POST https://translation.googleapis.com/language/translate/v2`, cu `source` și `target` explicite (`ro`, `vi`) și `format: "text"`.

- Suportă româna și vietnameza în ambele direcții.
- Cheia se trimite în header (`X-Goog-Api-Key`), nu în URL.
- Codul: `lib/translate-core.ts` (clientul) și `lib/translation-service.ts` (rezervare, salvare, erori).

---

## 4. Variabile de mediu (exact acestea)

| Variabilă | Unde se găsește | Public? |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | Supabase → Project Settings → API → Project URL | da (prin design) |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Supabase → API Keys → cheia **anon** sau **publishable** | da (protejată de RLS) |
| `SUPABASE_SERVICE_ROLE_KEY` | Supabase → API Keys → cheia **service_role** sau **secret** | **NU, doar server** |
| `GOOGLE_TRANSLATE_API_KEY` | Google Cloud → APIs & Services → Credentials | **NU, doar server** |
| `MESSAGES_PER_MINUTE` | opțional (implicit 20) | – |

Model: `.env.example`. Nu pune niciodată chei reale în repository.

---

## 5. Configurare Supabase (pas cu pas)

1. Creează un proiect pe [supabase.com](https://supabase.com), regiunea cea mai apropiată (de exemplu Frankfurt).
2. **SQL Editor** → lipește tot conținutul din `supabase/schema.sql` → **Run**.
3. **Authentication → Sign In / Providers → Email**: activează Email.
4. **Authentication → Users → Add user → Create new user**: creează **două conturi** (al tău și al ei), cu „Auto Confirm User” bifat și parole puternice.
5. Copiază **UUID-ul** fiecărui cont.
6. Deschide `supabase/seed.sql`, înlocuiește `UUID-CONT-DEVMIO` și `UUID-CONT-EA` cu UUID-urile copiate și rulează-l în **SQL Editor**.
7. **Authentication → Sign In / Providers**: **dezactivează „Allow new users to sign up”**, ca nimeni altcineva să nu-și poată face cont.
8. **Database → Publications** (sau **Realtime**): verifică faptul că tabela `messages` apare la `supabase_realtime`. Scriptul o adaugă automat.
9. **Project Settings → API**: copiază URL-ul, cheia anon/publishable și cheia service_role/secret.

## 6. Configurare Google Translation

1. [console.cloud.google.com](https://console.cloud.google.com): creează un proiect și activează **Billing**. Primele 500.000 de caractere pe lună sunt gratuite la Basic v2.
2. **APIs & Services → Library** → activează **Cloud Translation API**.
3. **Credentials → Create credentials → API key**.
4. **Restricționează cheia:** la **API restrictions** alege doar „Cloud Translation API”.

## 7. Publicare pe Vercel

1. Pune proiectul într-un repository GitHub privat (`.env` e deja ignorat).
2. [vercel.com](https://vercel.com) → **Add New → Project** → importă repository-ul. Framework-ul (Next.js) e detectat automat.
3. **Environment Variables**: adaugă cele 4 variabile din secțiunea 4, pentru **Production** (și Preview dacă vrei).
4. **Deploy**. Primești un link HTTPS, de exemplu `love-chat-xxx.vercel.app`.
5. În Supabase → **Authentication → URL Configuration**: pune linkul Vercel la **Site URL**.
6. Deschide linkul pe telefonul tău și pe al ei. Fiecare intră cu contul lui.

Rulare locală: `npm install` → copiezi `.env.example` în `.env.local` și îl completezi → `npm run dev`.

---

## 8. Teste: ce s-a executat și ce rămâne

**Executate (în mediul de dezvoltare, fără acces la internet):**

| Verificare | Comandă | Rezultat |
|---|---|---|
| Teste unitare: validare, diacritice RO/VI, emoji, NFC, paragrafe, limite | `npm test` | ✅ 19/19 trecute |
| Clientul de traducere: cerere corectă ro→vi și vi→ro, cheie în header, erori 4xx/5xx/429, răspuns gol, rețea căzută, fără traduceri inventate (fetch simulat doar în test) | `npm test` | ✅ |
| Logica de sincronizare: fără duplicate, înlocuirea mesajului optimist, ordonare, „Vezi originalul” / înapoi, destinatarul nu vede originalul în locul traducerii | `npm test` | ✅ |
| TypeScript strict pe modulele fără dependențe externe (`lib/types`, `validate`, `translate-core`, `messages`, `i18n`) | `tsc --noEmit` | ✅ 0 erori |
| Scanare de chei secrete în sursă și `.gitignore` | `npm run check:secrets` | ✅ nicio cheie găsită |

**NEexecutate, pentru că necesită internet, conturi și chei pe care nu le am:**
- `npm install`, `npm run typecheck` (tot proiectul), `npm run lint`, `npm run build`.
- Rularea SQL-ului pe Supabase (sintaxa nu a putut fi verificată pe un Postgres real).
- Testele 1–10 cu serviciile reale.

**Cum le rulezi după configurare:**
```bash
npm install
npm run typecheck && npm run lint && npm test && npm run build
npm run check:secrets          # după build: verifică și bundle-ul din browser (Testul 9)
BASE_URL=https://linkul-tau.vercel.app \
NEXT_PUBLIC_SUPABASE_URL=... NEXT_PUBLIC_SUPABASE_ANON_KEY=... \
DEVMIO_EMAIL=... DEVMIO_PASSWORD=... GIRL_EMAIL=... GIRL_PASSWORD=... \
npm run smoke                  # Testele 1, 2, 3, 4, 5, 6, 7, 8 automat, pe serviciile reale
```
Scriptul `smoke` trimite **două mesaje reale de test**, marcate „[test]”.

**Verificare manuală pe două telefoane (Testele 5 și 10):** deschizi linkul pe ambele, trimiți câte un mesaj și verifici că apare pe celălalt fără refresh. Apoi pui un telefon în mod avion, trimiți de pe celălalt, revii online și verifici că mesajul apare.

---

## 9. Ce mai necesită intervenția ta

1. Proiectul Supabase: rulezi `schema.sql`, creezi cele 2 conturi, rulezi `seed.sql` și dezactivezi înregistrările.
2. Cheia Google Translation, cu Billing activ.
3. Repository GitHub și deploy pe Vercel, cu cele 4 variabile.
4. Rulezi `npm run build` și `npm run smoke` și îmi trimiți rezultatul. Dacă apare o eroare, o repar.
5. Opțional: o verificare a textelor vietnamezi din interfață (`lib/i18n.ts`) de către ea.

## Structura proiectului
```
app/                 pagini (chat, login, setări), rute API, manifest PWA
  api/messages/      POST trimite + traduce; [id]/retry reîncearcă traducerea
  api/profile/       PATCH nume afișat
components/          Chat, MessageBubble, Composer, SettingsForm
lib/                 auth, validare, traducere, sincronizare, i18n, clienți Supabase
supabase/            schema.sql (tabele, RLS, realtime), seed.sql
scripts/             smoke-test.mjs (E2E real), check-secrets.mjs
tests/               teste unitare (node:test)
```
