"use client";

import { useState } from "react";
import { msgTime, visibleText } from "@/lib/messages";
import { t, theySee } from "@/lib/i18n";
import type { ClientMessage, Profile } from "@/lib/types";

type Props = {
  m: ClientMessage;
  me: Profile;
  other: Profile;
  grouped: boolean;
  onRetryTranslation: (id: string) => void;
  onResend: (m: ClientMessage) => void;
};

export default function MessageBubble({ m, me, other, grouped, onRetryTranslation, onResend }: Props) {
  const [alt, setAlt] = useState(false);
  const mine = m.sender_id === me.id;
  const L = me.lang;
  const sender = mine ? me : other;
  const time = new Date(msgTime(m.created_at)).toLocaleTimeString(L === "ro" ? "ro-RO" : "vi-VN", {
    hour: "2-digit",
    minute: "2-digit",
  });

  // Logica de afișare e în lib/messages.ts (acoperită de teste).
  const text = visibleText(m, me.id, alt);
  let body: React.ReactNode;
  let label: string | null = null;
  if (text !== null) {
    body = text;
    if (alt) label = mine ? theySee(L, other.display_name) : t(L, "original");
  } else if (m.translation_status === "failed") {
    body = <span className="italic opacity-80">{t(L, "translationFailed")}</span>;
  } else {
    // Traducerea e în curs: NU afișăm originalul în locul ei.
    body = (
      <span className="flex flex-col gap-1.5 py-1" aria-label={t(L, "translating")}>
        <span className="shimmer block h-2.5 w-40 rounded-full" />
        <span className="shimmer block h-2.5 w-24 rounded-full" />
      </span>
    );
  }

  const canToggle = mine ? m.translation_status === "done" && !!m.translated_text && !m.local : true;
  const toggleLabel = mine ? (alt ? t(L, "backToMine") : t(L, "showTranslation")) : alt ? t(L, "backToTranslation") : t(L, "showOriginal");

  let state: React.ReactNode = null;
  if (m.local === "sending") state = <span>{t(L, "sending")}</span>;
  else if (m.local === "unsent")
    state = (
      <button onClick={() => onResend(m)} className="font-semibold underline underline-offset-2">
        ⚠ {t(L, "unsent")} · {t(L, "resend")}
      </button>
    );
  else if (m.translation_status === "pending") state = <span>{t(L, "translating")}</span>;
  else if (m.translation_status === "failed")
    state = (
      <button onClick={() => onRetryTranslation(m.id)} className="font-semibold underline underline-offset-2">
        ! {t(L, "translationFailed")} · {t(L, "retry")}
      </button>
    );
  else if (mine) state = <span title={t(L, "translated")}>✓✓ {m.translated_lang.toUpperCase()}</span>;

  return (
    <div className={`bubble-in flex items-end gap-2 ${mine ? "justify-end" : "justify-start"} ${grouped ? "" : "mt-2"}`}>
      {!mine && (
        <span
          className={`mb-5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-gold text-xs font-semibold text-white ${
            grouped ? "invisible" : ""
          }`}
          aria-hidden
        >
          {[...sender.display_name.trim()][0]?.toUpperCase()}
        </span>
      )}
      <div className={`flex max-w-[82%] flex-col sm:max-w-[70%] ${mine ? "items-end" : "items-start"}`}>
        {!grouped && <span className="mb-1 px-2 text-[11px] font-semibold opacity-60">{mine ? t(L, "you") : sender.display_name}</span>}
        <div
          className={`relative whitespace-pre-wrap break-words rounded-3xl px-4 py-2.5 text-[15px] leading-relaxed shadow-soft ${
            mine
              ? "rounded-br-lg bg-wine-700 text-white"
              : "rounded-bl-lg border border-black/5 bg-white text-ink dark:border-white/5 dark:bg-night-800 dark:text-[#F3ECEF]"
          } ${m.local === "unsent" ? "opacity-70" : ""}`}
        >
          {label && <span className={`mb-1 block text-[11px] font-semibold uppercase tracking-wider ${mine ? "text-white/70" : "text-wine-600 dark:text-wine-300"}`}>{label}</span>}
          {body}
        </div>
        <div className={`mt-1 flex flex-wrap items-center gap-x-2 px-2 text-[11px] opacity-65 ${mine ? "justify-end" : ""}`}>
          <time dateTime={m.created_at}>{time}</time>
          {state && <span aria-live="polite">{state}</span>}
          {canToggle && (
            <button onClick={() => setAlt((v) => !v)} className="font-medium underline-offset-2 hover:underline">
              {toggleLabel}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
