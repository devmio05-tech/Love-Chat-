"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import { mergeMessages, msgTime } from "@/lib/messages";
import { emptyText, t as tr, type I18nKey } from "@/lib/i18n";
import type { ClientMessage, Message, Profile } from "@/lib/types";
import MessageBubble from "./MessageBubble";
import Composer from "./Composer";

type Conn = "online" | "connecting";

function newClientId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  const b = crypto.getRandomValues(new Uint8Array(16));
  b[6] = (b[6] & 0x0f) | 0x40;
  b[8] = (b[8] & 0x3f) | 0x80;
  const h = [...b].map((x) => x.toString(16).padStart(2, "0")).join("");
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}

function Avatar({ name, tone }: { name: string; tone: "me" | "other" }) {
  const initial = [...name.trim()][0]?.toUpperCase() ?? "?";
  return (
    <span
      className={`flex h-9 w-9 items-center justify-center rounded-full text-sm font-semibold ring-2 ring-ivory dark:ring-night-900 ${
        tone === "me" ? "bg-wine-700 text-white" : "bg-gold text-white"
      }`}
      aria-hidden
    >
      {initial}
    </span>
  );
}

export default function Chat({ me, other, initialMessages }: { me: Profile; other: Profile; initialMessages: Message[] }) {
  const supabase = useMemo(() => createClient(), []);
  const [messages, setMessages] = useState<ClientMessage[]>(() => mergeMessages([], initialMessages));
  const [conn, setConn] = useState<Conn>("connecting");
  const [online, setOnline] = useState(true);
  const t = useCallback((k: I18nKey) => tr(me.lang, k), [me.lang]);

  const listRef = useRef<HTMLDivElement>(null);
  const messagesRef = useRef(messages);
  messagesRef.current = messages;
  const lastRetry = useRef(new Map<string, number>());
  const stickToBottom = useRef(true);

  const merge = useCallback((incoming: ClientMessage[]) => setMessages((cur) => mergeMessages(cur, incoming)), []);

  useEffect(() => {
    document.documentElement.lang = me.lang;
  }, [me.lang]);

  /** Recuperează mesajele care puteau lipsi (după reconectare sau revenire în aplicație). */
  const resync = useCallback(async () => {
    const cur = messagesRef.current.filter((m) => !m.local);
    const last = cur[cur.length - 1];
    const query = last
      ? supabase.from("messages").select("*").gte("created_at", last.created_at).order("created_at", { ascending: true }).order("id", { ascending: true }).limit(500)
      : supabase.from("messages").select("*").order("created_at", { ascending: false }).order("id", { ascending: false }).limit(200);
    const { data, error } = await query;
    if (!error && data) merge(data as Message[]);
    const unfinished = cur.filter((m) => m.translation_status !== "done").map((m) => m.id).slice(-50);
    if (unfinished.length) {
      const res = await supabase.from("messages").select("*").in("id", unfinished);
      if (!res.error && res.data) merge(res.data as Message[]);
    }
  }, [supabase, merge]);
  const resyncRef = useRef(resync);
  resyncRef.current = resync;

  // Sincronizare în timp real (Supabase Realtime, filtrat de RLS).
  useEffect(() => {
    let alive = true;
    let channel: ReturnType<typeof supabase.channel> | null = null;
    (async () => {
      const { data } = await supabase.auth.getSession();
      if (data.session) supabase.realtime.setAuth(data.session.access_token);
      if (!alive) return;
      channel = supabase
        .channel("love-chat-messages")
        .on("postgres_changes", { event: "*", schema: "public", table: "messages" }, (payload) => {
          const row = payload.new as Message | undefined;
          if (row && row.id) merge([row]);
        })
        .subscribe((status) => {
          if (!alive) return;
          if (status === "SUBSCRIBED") {
            setConn("online");
            void resyncRef.current();
          } else {
            setConn("connecting");
          }
        });
    })();
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (session) supabase.realtime.setAuth(session.access_token);
      if (event === "SIGNED_OUT") window.location.href = "/login";
    });
    return () => {
      alive = false;
      sub.subscription.unsubscribe();
      if (channel) void supabase.removeChannel(channel);
    };
  }, [supabase, merge]);

  // Stare internet + revenire în aplicație.
  useEffect(() => {
    const on = () => {
      setOnline(true);
      void resyncRef.current();
    };
    const off = () => setOnline(false);
    const vis = () => {
      if (document.visibilityState === "visible") void resyncRef.current();
    };
    setOnline(navigator.onLine);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    document.addEventListener("visibilitychange", vis);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
      document.removeEventListener("visibilitychange", vis);
    };
  }, []);

  const retryTranslation = useCallback(
    async (id: string) => {
      lastRetry.current.set(id, Date.now());
      try {
        const res = await fetch(`/api/messages/${id}/retry`, { method: "POST" });
        if (res.status === 401) {
          window.location.href = "/login";
          return;
        }
        const json = (await res.json().catch(() => null)) as { message?: Message } | null;
        if (json?.message) merge([json.message]);
      } catch {
        /* rețea indisponibilă: se reîncearcă automat */
      }
    },
    [merge],
  );

  // Reîncercare automată, cu pauze tot mai mari, pentru traducerile eșuate sau blocate.
  useEffect(() => {
    const iv = setInterval(() => {
      if (!navigator.onLine) return;
      const now = Date.now();
      for (const m of messagesRef.current) {
        if (m.local) continue;
        const stalePending = m.translation_status === "pending" && now - msgTime(m.created_at) > 35_000;
        const failed = m.translation_status === "failed" && m.translation_attempts < 5;
        if (!stalePending && !failed) continue;
        const wait = Math.min(60_000, 8_000 * 2 ** Math.max(0, m.translation_attempts - 1));
        if (now - (lastRetry.current.get(m.id) ?? 0) < wait) continue;
        void retryTranslation(m.id);
      }
    }, 4_000);
    return () => clearInterval(iv);
  }, [retryTranslation]);

  const send = useCallback(
    async (text: string, existingClientId?: string) => {
      const clientId = existingClientId ?? newClientId();
      const temp: ClientMessage = {
        id: `local-${clientId}`,
        client_id: clientId,
        sender_id: me.id,
        original_text: text,
        original_lang: me.lang,
        translated_text: null,
        translated_lang: other.lang,
        translation_status: "pending",
        translation_error: null,
        translation_attempts: 0,
        created_at: new Date().toISOString(),
        translated_at: null,
        local: "sending",
      };
      stickToBottom.current = true;
      merge([temp]);
      try {
        const res = await fetch("/api/messages", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ clientId, text }),
        });
        if (res.status === 401) {
          window.location.href = "/login";
          return;
        }
        const json = (await res.json().catch(() => null)) as { message?: Message; error?: string } | null;
        if (!res.ok || !json?.message) throw new Error(json?.error ?? t("errorSend"));
        merge([json.message]);
      } catch (e) {
        const reason = e instanceof Error ? e.message : t("errorSend");
        setMessages((cur) => cur.map((m) => (m.id === temp.id ? { ...m, local: "unsent", translation_error: reason } : m)));
      }
    },
    [me.id, me.lang, other.lang, merge, t],
  );

  // Derulare automată la mesajele noi.
  useEffect(() => {
    const el = listRef.current;
    if (el && stickToBottom.current) el.scrollTop = el.scrollHeight;
  }, [messages]);
  const onScroll = () => {
    const el = listRef.current;
    if (el) stickToBottom.current = el.scrollHeight - el.scrollTop - el.clientHeight < 120;
  };

  const dayLabel = (iso: string) => {
    const d = new Date(msgTime(iso));
    const today = new Date();
    const y = new Date();
    y.setDate(today.getDate() - 1);
    if (d.toDateString() === today.toDateString()) return t("today");
    if (d.toDateString() === y.toDateString()) return t("yesterday");
    return d.toLocaleDateString(me.lang === "ro" ? "ro-RO" : "vi-VN", { day: "numeric", month: "long", year: "numeric" });
  };

  const status = !online ? "offline" : conn;

  return (
    <div className="app-bg flex h-dvh flex-col">
      <header className="safe-top sticky top-0 z-10 border-b border-black/5 bg-ivory/85 backdrop-blur-xl dark:border-white/5 dark:bg-night-900/85">
        <div className="mx-auto flex max-w-3xl items-center gap-3 px-4 py-3">
          <div className="flex -space-x-2">
            <Avatar name={other.display_name} tone="other" />
            <Avatar name={me.display_name} tone="me" />
          </div>
          <div className="min-w-0 flex-1">
            <h1 className="truncate font-serif text-xl italic leading-tight">{other.display_name}</h1>
            <p className="flex items-center gap-2 text-[11px] font-medium opacity-70">
              <span
                className={`inline-block h-2 w-2 rounded-full ${
                  status === "online" ? "bg-emerald-500" : status === "offline" ? "bg-wine-500" : "animate-pulse bg-amber-500"
                }`}
              />
              {status === "online" ? t("online") : status === "offline" ? t("offline").split(".")[0] : t("connecting")}
            </p>
          </div>
          <span
            className="hidden items-center gap-1.5 rounded-full border border-wine-500/25 px-3 py-1 text-[11px] font-semibold tracking-wider text-wine-700 sm:flex dark:text-wine-300"
            title={t("autoTranslate")}
          >
            {me.lang.toUpperCase()} <span aria-hidden>⇄</span> {other.lang.toUpperCase()} <span aria-hidden>♥</span>
          </span>
          <Link
            href="/settings"
            aria-label={t("settings")}
            className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-black/5 dark:hover:bg-white/10"
          >
            <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.8">
              <circle cx="12" cy="12" r="3" />
              <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z" />
            </svg>
          </Link>
        </div>
        {status === "offline" && (
          <div className="bg-wine-700 px-4 py-1.5 text-center text-xs font-medium text-white" role="status">
            {t("offline")}
          </div>
        )}
      </header>

      <div ref={listRef} onScroll={onScroll} className="flex-1 overflow-y-auto overscroll-contain">
        <div className="mx-auto flex max-w-3xl flex-col gap-1.5 px-3 py-4 sm:px-6">
          {messages.length === 0 && (
            <div className="mx-auto mt-16 max-w-xs text-center">
              <p className="font-serif text-2xl italic">{t("emptyTitle")}</p>
              <p className="mt-2 text-sm opacity-70">{emptyText(me.lang, other.display_name)}</p>
              <p className="mt-4 text-xs tracking-[.25em] text-wine-600 dark:text-wine-300">RO ⇄ VI</p>
            </div>
          )}
          {messages.map((m, i) => {
            const prev = messages[i - 1];
            const newDay = !prev || new Date(msgTime(prev.created_at)).toDateString() !== new Date(msgTime(m.created_at)).toDateString();
            const grouped = !!prev && !newDay && prev.sender_id === m.sender_id && msgTime(m.created_at) - msgTime(prev.created_at) < 120_000;
            return (
              <div key={m.id}>
                {newDay && (
                  <div className="my-4 flex justify-center">
                    <span className="rounded-full bg-black/5 px-3 py-1 text-[11px] font-semibold opacity-70 dark:bg-white/10">
                      {dayLabel(m.created_at)}
                    </span>
                  </div>
                )}
                <MessageBubble
                  m={m}
                  me={me}
                  other={other}
                  grouped={grouped}
                  onRetryTranslation={retryTranslation}
                  onResend={(msg) => void send(msg.original_text, msg.client_id)}
                />
              </div>
            );
          })}
        </div>
      </div>

      <Composer lang={me.lang} onSend={(text) => void send(text)} />
    </div>
  );
}
