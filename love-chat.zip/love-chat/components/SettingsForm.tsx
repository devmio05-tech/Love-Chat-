"use client";

import { useState } from "react";
import Link from "next/link";
import { langName, t } from "@/lib/i18n";
import type { Profile } from "@/lib/types";

export default function SettingsForm({ me, profiles }: { me: Profile; profiles: Profile[] }) {
  const L = me.lang;
  const [names, setNames] = useState<Record<string, string>>(() => Object.fromEntries(profiles.map((p) => [p.id, p.display_name])));
  const [state, setState] = useState<Record<string, "idle" | "saving" | "saved" | "error">>({});

  async function save(p: Profile) {
    setState((s) => ({ ...s, [p.id]: "saving" }));
    const res = await fetch("/api/profile", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId: p.id, displayName: names[p.id] }),
    }).catch(() => null);
    setState((s) => ({ ...s, [p.id]: res?.ok ? "saved" : "error" }));
  }

  const ordered = [...profiles].sort((a) => (a.id === me.id ? -1 : 1));

  return (
    <main className="app-bg safe-top min-h-dvh">
      <div className="mx-auto max-w-lg px-5 py-6">
        <Link href="/" className="text-sm font-semibold text-wine-700 dark:text-wine-300">
          ← {t(L, "back")}
        </Link>
        <h1 className="mt-4 font-serif text-3xl italic">{t(L, "settings")}</h1>
        <div className="mt-6 flex flex-col gap-4">
          {ordered.map((p) => (
            <section key={p.id} className="rounded-3xl bg-white/85 p-5 shadow-soft dark:bg-night-800">
              <label className="text-xs font-semibold uppercase tracking-wider opacity-70" htmlFor={`n-${p.id}`}>
                {t(L, "displayName")} {p.id === me.id ? `(${t(L, "you")})` : ""}
              </label>
              <div className="mt-2 flex gap-2">
                <input
                  id={`n-${p.id}`}
                  value={names[p.id] ?? ""}
                  maxLength={40}
                  onChange={(e) => {
                    const v = e.target.value;
                    setNames((n) => ({ ...n, [p.id]: v }));
                    setState((s) => ({ ...s, [p.id]: "idle" }));
                  }}
                  className="min-w-0 flex-1 rounded-2xl border border-black/10 bg-white px-4 py-2.5 text-base outline-none focus:border-wine-500 dark:border-white/10 dark:bg-night-900"
                />
                <button
                  onClick={() => void save(p)}
                  disabled={state[p.id] === "saving"}
                  className="rounded-2xl bg-wine-700 px-4 text-sm font-semibold text-white disabled:opacity-60"
                >
                  {state[p.id] === "saved" ? t(L, "saved") : t(L, "save")}
                </button>
              </div>
              {state[p.id] === "error" && <p className="mt-2 text-sm text-wine-600">{t(L, "errorSave")}</p>}
              <p className="mt-3 text-sm opacity-70">
                {t(L, "language")}: <strong>{langName(L, p.lang)}</strong>
              </p>
            </section>
          ))}
        </div>
        <form action="/auth/signout" method="post" className="mt-8">
          <button className="w-full rounded-2xl border border-black/10 py-3 text-sm font-semibold dark:border-white/10">{t(L, "logout")}</button>
        </form>
      </div>
    </main>
  );
}
