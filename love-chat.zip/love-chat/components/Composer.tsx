"use client";

import { useRef, useState } from "react";
import { MAX_MESSAGE_CHARS } from "@/lib/validate";
import { t } from "@/lib/i18n";
import type { Lang } from "@/lib/types";

export default function Composer({ lang, onSend }: { lang: Lang; onSend: (text: string) => void }) {
  const [text, setText] = useState("");
  const ref = useRef<HTMLTextAreaElement>(null);
  const count = [...text].length;
  const canSend = text.trim().length > 0 && count <= MAX_MESSAGE_CHARS;

  const resize = () => {
    const el = ref.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 160) + "px";
  };

  const submit = () => {
    if (!canSend) return;
    onSend(text.trim());
    setText("");
    requestAnimationFrame(() => {
      resize();
      ref.current?.focus();
    });
  };

  return (
    <div className="safe-bottom border-t border-black/5 bg-ivory/90 backdrop-blur-xl dark:border-white/5 dark:bg-night-900/90">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit();
        }}
        className="mx-auto flex max-w-3xl items-end gap-2 px-3 pt-2.5 sm:px-6"
      >
        <textarea
          ref={ref}
          value={text}
          rows={1}
          lang={lang}
          placeholder={t(lang, "typeMessage")}
          onChange={(e) => {
            setText(e.target.value);
            resize();
          }}
          onKeyDown={(e) => {
            // Pe calculator: Enter trimite, Shift+Enter rând nou. Pe telefon: Enter = rând nou.
            const touch = typeof window !== "undefined" && window.matchMedia("(pointer: coarse)").matches;
            if (e.key === "Enter" && !e.shiftKey && !touch && !e.nativeEvent.isComposing) {
              e.preventDefault();
              submit();
            }
          }}
          className="max-h-40 min-h-[48px] flex-1 resize-none rounded-3xl border border-black/10 bg-white px-4 py-3 text-base leading-snug outline-none focus:border-wine-500 dark:border-white/10 dark:bg-night-800"
        />
        <button
          type="submit"
          disabled={!canSend}
          aria-label={t(lang, "send")}
          className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-wine-700 text-white shadow-soft transition active:scale-95 disabled:opacity-40"
        >
          <svg viewBox="0 0 24 24" className="h-5 w-5" fill="currentColor" aria-hidden>
            <path d="M3.4 20.4 21 12 3.4 3.6l-.01 6.53L15 12 3.39 13.87z" />
          </svg>
        </button>
      </form>
      {count > MAX_MESSAGE_CHARS - 300 && (
        <p className={`mx-auto max-w-3xl px-6 pt-1 text-right text-[11px] ${count > MAX_MESSAGE_CHARS ? "text-wine-600" : "opacity-60"}`}>
          {count}/{MAX_MESSAGE_CHARS}
        </p>
      )}
    </div>
  );
}
