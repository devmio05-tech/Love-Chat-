import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Love Chat",
    short_name: "Love Chat",
    description: "Română ↔ Tiếng Việt, tradus automat",
    start_url: "/",
    display: "standalone",
    background_color: "#FBF6F3",
    theme_color: "#7A2A41",
    icons: [
      { src: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { src: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
      { src: "/icons/icon-maskable-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
  };
}
