import { redirect } from "next/navigation";
import { getMember } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import Chat from "@/components/Chat";
import type { Message } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function Home() {
  const auth = await getMember();
  if (!auth.ok) {
    if (auth.status === 401) redirect("/login");
    return (
      <main className="app-bg flex min-h-dvh items-center justify-center p-6 text-center">
        <div className="max-w-sm rounded-3xl bg-white/80 p-8 shadow-soft dark:bg-night-800">
          <h1 className="font-serif text-2xl italic">Love Chat</h1>
          <p className="mt-3 text-sm opacity-80">{auth.error}</p>
          <form action="/auth/signout" method="post" className="mt-6">
            <button className="rounded-full bg-wine-700 px-5 py-2.5 text-sm font-semibold text-white">Ieșire · Đăng xuất</button>
          </form>
        </div>
      </main>
    );
  }

  // Citire cu sesiunea utilizatorului: RLS din Supabase permite doar membrilor să vadă mesajele.
  const supabase = await createClient();
  const { data } = await supabase
    .from("messages")
    .select("*")
    .order("created_at", { ascending: false })
    .order("id", { ascending: false })
    .limit(200);
  const initialMessages = ((data ?? []) as Message[]).reverse();

  return <Chat me={auth.ctx.me} other={auth.ctx.other} initialMessages={initialMessages} />;
}
