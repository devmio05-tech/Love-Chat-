import { redirect } from "next/navigation";
import { getMember } from "@/lib/auth";
import SettingsForm from "@/components/SettingsForm";

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const auth = await getMember();
  if (!auth.ok) redirect(auth.status === 401 ? "/login" : "/");
  return <SettingsForm me={auth.ctx.me} profiles={auth.ctx.profiles} />;
}
