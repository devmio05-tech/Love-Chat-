import { NextResponse } from "next/server";
import { getMember, jsonError } from "@/lib/auth";
import { createAdminClient } from "@/lib/supabase/admin";
import { isUuid, validateDisplayName } from "@/lib/validate";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Schimbă numele afișat al unuia dintre cei doi membri (limba și rolul nu pot fi schimbate). */
export async function PATCH(req: Request) {
  const auth = await getMember(req);
  if (!auth.ok) return jsonError(auth.status, auth.error);
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return jsonError(400, "Cerere invalidă.");
  }
  const { userId, displayName } = (body ?? {}) as Record<string, unknown>;
  if (!isUuid(userId) || !auth.ctx.profiles.some((p) => p.id === userId)) return jsonError(400, "Utilizator invalid.");
  const v = validateDisplayName(displayName);
  if (!v.ok) return jsonError(400, v.error);

  const { data, error } = await createAdminClient()
    .from("profiles")
    .update({ display_name: v.text, updated_at: new Date().toISOString() })
    .eq("id", userId)
    .select("id, display_name, lang, role")
    .single();
  if (error) return jsonError(500, "Nu s-a putut salva.");
  return NextResponse.json({ profile: data });
}
