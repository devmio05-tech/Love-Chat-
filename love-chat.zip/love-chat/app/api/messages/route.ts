import { NextResponse } from "next/server";
import { getMember, jsonError } from "@/lib/auth";
import { createAdminClient } from "@/lib/supabase/admin";
import { isUuid, validateMessageText } from "@/lib/validate";
import { underMessageLimit } from "@/lib/rate-limit";
import { translateAndStore } from "@/lib/translation-service";
import type { Message } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Trimite un mesaj:
 * 1) verifică identitatea și apartenența la conversație,
 * 2) validează textul, 3) salvează originalul (idempotent după clientId),
 * 4) traduce în limba destinatarului și salvează traducerea.
 */
export async function POST(req: Request) {
  const auth = await getMember(req);
  if (!auth.ok) return jsonError(auth.status, auth.error);
  const { me, other } = auth.ctx;

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return jsonError(400, "Cerere invalidă.");
  }
  const { clientId, text } = (body ?? {}) as Record<string, unknown>;
  if (!isUuid(clientId)) return jsonError(400, "clientId invalid.");
  const v = validateMessageText(text);
  if (!v.ok) return jsonError(400, v.error);

  const admin = createAdminClient();

  // Idempotență: aceeași cerere trimisă de două ori nu creează două mesaje.
  const existing = await admin.from("messages").select("*").eq("sender_id", me.id).eq("client_id", clientId).maybeSingle();
  if (existing.data) {
    let m = existing.data as Message;
    if (m.translation_status !== "done") m = await translateAndStore(admin, m.id);
    return NextResponse.json({ message: m }, { headers: { "Cache-Control": "no-store" } });
  }

  if (!(await underMessageLimit(admin, me.id))) return jsonError(429, "Prea multe mesaje într-un minut. Așteaptă puțin.");

  const inserted = await admin
    .from("messages")
    .insert({
      client_id: clientId,
      sender_id: me.id,
      original_text: v.text,
      original_lang: me.lang, // limba sursă = limba expeditorului (ro pentru Devmio, vi pentru ea)
      translated_lang: other.lang, // limba destinatarului determină traducerea
      translation_status: "pending",
    })
    .select("*")
    .single();

  if (inserted.error || !inserted.data) {
    if (inserted.error?.code === "23505") {
      const again = await admin.from("messages").select("*").eq("sender_id", me.id).eq("client_id", clientId).single();
      if (again.data) return NextResponse.json({ message: again.data as Message });
    }
    console.error("insert message", inserted.error);
    return jsonError(500, "Mesajul nu a putut fi salvat.");
  }

  const message = await translateAndStore(admin, (inserted.data as Message).id);
  return NextResponse.json({ message }, { status: 201, headers: { "Cache-Control": "no-store" } });
}
