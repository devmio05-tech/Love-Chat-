import { NextResponse } from "next/server";
import { getMember, jsonError } from "@/lib/auth";
import { createAdminClient } from "@/lib/supabase/admin";
import { isUuid } from "@/lib/validate";
import { translateAndStore } from "@/lib/translation-service";
import type { Message } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Reîncearcă traducerea unui mesaj eșuat sau blocat. Nu creează mesaje noi. */
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await getMember(req);
  if (!auth.ok) return jsonError(auth.status, auth.error);
  const { id } = await params;
  if (!isUuid(id)) return jsonError(400, "ID invalid.");

  const admin = createAdminClient();
  const { data, error } = await admin.from("messages").select("*").eq("id", id).maybeSingle();
  if (error) return jsonError(500, "Eroare la citire.");
  if (!data) return jsonError(404, "Mesajul nu există.");
  let m = data as Message;
  if (m.translation_status !== "done") m = await translateAndStore(admin, m.id);
  return NextResponse.json({ message: m }, { headers: { "Cache-Control": "no-store" } });
}
