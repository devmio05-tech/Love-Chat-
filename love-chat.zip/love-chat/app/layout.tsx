import type { Metadata, Viewport } from "next";
import { Be_Vietnam_Pro, Playfair_Display } from "next/font/google";
import SWRegister from "@/components/SWRegister";
import "./globals.css";

// Ambele fonturi au subseturi pentru latin-ext (ă â î ș ț) și vietnameză.
const sans = Be_Vietnam_Pro({
  subsets: ["latin", "latin-ext", "vietnamese"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-sans",
  display: "swap",
});
const serif = Playfair_Display({
  subsets: ["latin", "latin-ext", "vietnamese"],
  style: ["normal", "italic"],
  variable: "--font-serif",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Love Chat",
  description: "Conversație privată cu traducere automată română ↔ vietnameză",
  applicationName: "Love Chat",
  appleWebApp: { capable: true, title: "Love Chat", statusBarStyle: "default" },
  icons: { icon: "/icons/icon-192.png", apple: "/icons/apple-touch-icon.png" },
  robots: { index: false, follow: false },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#FBF6F3" },
    { media: "(prefers-color-scheme: dark)", color: "#17121A" },
  ],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ro" className={`${sans.variable} ${serif.variable}`}>
      <body className="font-sans">
        {children}
        <SWRegister />
      </body>
    </html>
  );
}
