"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const supabase = createClient();
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    setBusy(false);
    if (error) {
      setError("Email sau parolă greșită · Email hoặc mật khẩu không đúng");
      return;
    }
    router.replace("/");
    router.refresh();
  }

  return (
    <main className="app-bg safe-top flex min-h-dvh items-center justify-center p-6">
      <form onSubmit={onSubmit} className="w-full max-w-sm rounded-[28px] bg-white/85 p-8 shadow-soft backdrop-blur dark:bg-night-800/90">
        <div className="text-center">
          <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-wine-700 text-2xl text-white">♥</div>
          <h1 className="font-serif text-4xl italic">Love Chat</h1>
          <p className="mt-2 text-xs tracking-[.2em] text-wine-600 dark:text-wine-300">RO ⇄ VI</p>
        </div>
        <label className="mt-8 block text-xs font-semibold uppercase tracking-wider opacity-70" htmlFor="email">
          Email
        </label>
        <input
          id="email"
          type="email"
          autoComplete="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="mt-1.5 w-full rounded-2xl border border-black/10 bg-white px-4 py-3 text-base outline-none focus:border-wine-500 dark:border-white/10 dark:bg-night-900"
        />
        <label className="mt-4 block text-xs font-semibold uppercase tracking-wider opacity-70" htmlFor="password">
          Parolă · Mật khẩu
        </label>
        <input
          id="password"
          type="password"
          autoComplete="current-password"
          required
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="mt-1.5 w-full rounded-2xl border border-black/10 bg-white px-4 py-3 text-base outline-none focus:border-wine-500 dark:border-white/10 dark:bg-night-900"
        />
        {error && <p className="mt-4 text-sm text-wine-600 dark:text-wine-300" role="alert">{error}</p>}
        <button
          disabled={busy}
          className="mt-6 w-full rounded-2xl bg-wine-700 py-3.5 font-semibold text-white transition active:scale-[.98] disabled:opacity-60"
        >
          {busy ? "…" : "Intră · Đăng nhập"}
        </button>
      </form>
    </main>
  );
}
